/**
implement a circular version of a doubly linked ist ,without any sentinels
 that supports all the public behaviors of the original as well as two new
 update methods rotate()and rotate Backward()
 */
public class Nodes5 {
    static class Node{
        char data;
        Node prev;
        Node next;
    }
    static Node head=null;
    static void rotate(int S){
        if (S==0)
            return;
    }
}
