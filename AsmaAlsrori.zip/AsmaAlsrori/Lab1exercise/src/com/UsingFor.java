package com;

public class UsingFor {
    public static void main(String[] args) {
        System.out.println("Hello World ");
        for (int i = 1; i <=10 ; i++) {
            System.out.println(i);

        }
    }
}
